# Application Cinéma

Voir fichiers **docs/INSTALL.md** pour les consignes d'installation