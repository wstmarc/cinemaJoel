# Installation du projet

## Les dossiers fournis
* sql : contient le script nécessaire pour créer la base de données avec
le jeu de données de départ
* images : contient toutes les images du jeu de données de départ

## La configurtion
Il faut modifier le fichier `application.properties` pour régler :
* l'URL JDBC
* le dossier d'accès aux images

